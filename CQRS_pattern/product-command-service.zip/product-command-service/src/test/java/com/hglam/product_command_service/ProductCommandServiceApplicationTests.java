package com.hglam.product_command_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCommandServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
